package com.erick.ivan.practica.modelo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetConjuntotiendasUsuarioResult {

    @SerializedName("Activo")
    @Expose
    private Integer activo;
    @SerializedName("Altitud")
    @Expose
    private Integer altitud;
    @SerializedName("AreaFlexFrentes")
    @Expose
    private Object areaFlexFrentes;
    @SerializedName("ArietesFrentes")
    @Expose
    private Object arietesFrentes;
    @SerializedName("Bateria")
    @Expose
    private Object bateria;
    @SerializedName("CP")
    @Expose
    private Integer cP;
    @SerializedName("CabeceraFrentes")
    @Expose
    private Object cabeceraFrentes;
    @SerializedName("Cadena")
    @Expose
    private String cadena;
    @SerializedName("CadenaFecha")
    @Expose
    private Object cadenaFecha;
    @SerializedName("CajasFrentes")
    @Expose
    private Object cajasFrentes;
    @SerializedName("Calle")
    @Expose
    private Object calle;
    @SerializedName("CantAnaquel")
    @Expose
    private Object cantAnaquel;
    @SerializedName("CantBodega")
    @Expose
    private Object cantBodega;
    @SerializedName("CantFrentesEnFrio")
    @Expose
    private Object cantFrentesEnFrio;
    @SerializedName("Colonia")
    @Expose
    private String colonia;
    @SerializedName("ComentarioAnaquel")
    @Expose
    private Object comentarioAnaquel;
    @SerializedName("ComentarioBodega")
    @Expose
    private Object comentarioBodega;
    @SerializedName("ComentarioExhAdic")
    @Expose
    private Object comentarioExhAdic;
    @SerializedName("ComentarioFrentesEnFrio")
    @Expose
    private Object comentarioFrentesEnFrio;
    @SerializedName("DeterminanteGSP")
    @Expose
    private Integer determinanteGSP;
    @SerializedName("DeterminanteTienda")
    @Expose
    private String determinanteTienda;
    @SerializedName("Direccion")
    @Expose
    private String direccion;
    @SerializedName("Estatus")
    @Expose
    private Object estatus;
    @SerializedName("Facturacion")
    @Expose
    private Object facturacion;
    @SerializedName("Fecha")
    @Expose
    private String fecha;
    @SerializedName("FechaSync")
    @Expose
    private String fechaSync;
    @SerializedName("ForwayFrentes")
    @Expose
    private Object forwayFrentes;
    @SerializedName("Id")
    @Expose
    private Integer id;
    @SerializedName("IdCadena")
    @Expose
    private Integer idCadena;
    @SerializedName("IdCanal")
    @Expose
    private Integer idCanal;
    @SerializedName("IdCategoria")
    @Expose
    private Integer idCategoria;
    @SerializedName("IdCiudad")
    @Expose
    private Object idCiudad;
    @SerializedName("IdEstado")
    @Expose
    private Object idEstado;
    @SerializedName("IdFormato")
    @Expose
    private Object idFormato;
    @SerializedName("IdFoto")
    @Expose
    private Object idFoto;
    @SerializedName("IdGrupo")
    @Expose
    private Integer idGrupo;
    @SerializedName("IdMunicipio")
    @Expose
    private Object idMunicipio;
    @SerializedName("IdPais")
    @Expose
    private Object idPais;
    @SerializedName("IdProyecto")
    @Expose
    private Object idProyecto;
    @SerializedName("IdUsuario")
    @Expose
    private Object idUsuario;
    @SerializedName("IdVisita_Server")
    @Expose
    private Integer idVisitaServer;
    @SerializedName("IsAreaFlex")
    @Expose
    private Object isAreaFlex;
    @SerializedName("IsAriete")
    @Expose
    private Object isAriete;
    @SerializedName("IsBunkers")
    @Expose
    private Object isBunkers;
    @SerializedName("IsC1")
    @Expose
    private Object isC1;
    @SerializedName("IsC2")
    @Expose
    private Object isC2;
    @SerializedName("IsC3")
    @Expose
    private Object isC3;
    @SerializedName("IsC4")
    @Expose
    private Object isC4;
    @SerializedName("IsCabecera")
    @Expose
    private Object isCabecera;
    @SerializedName("IsCajas")
    @Expose
    private Object isCajas;
    @SerializedName("IsExhibidores")
    @Expose
    private Object isExhibidores;
    @SerializedName("IsForway")
    @Expose
    private Object isForway;
    @SerializedName("IsIsla")
    @Expose
    private Object isIsla;
    @SerializedName("IsMaterialPOP")
    @Expose
    private Object isMaterialPOP;
    @SerializedName("IsOtro")
    @Expose
    private Object isOtro;
    @SerializedName("IsTiras")
    @Expose
    private Object isTiras;
    @SerializedName("IslasFrentes")
    @Expose
    private Object islasFrentes;
    @SerializedName("Latitud")
    @Expose
    private Double latitud;
    @SerializedName("Longitud")
    @Expose
    private Double longitud;
    @SerializedName("Manos")
    @Expose
    private Object manos;
    @SerializedName("ManosC1")
    @Expose
    private Object manosC1;
    @SerializedName("ManosC2")
    @Expose
    private Object manosC2;
    @SerializedName("ManosC3")
    @Expose
    private Object manosC3;
    @SerializedName("ManosC4")
    @Expose
    private Object manosC4;
    @SerializedName("ManosFrentesEnFrio")
    @Expose
    private Object manosFrentesEnFrio;
    @SerializedName("MatPOPCartulina")
    @Expose
    private Object matPOPCartulina;
    @SerializedName("MatPOPCenefas")
    @Expose
    private Object matPOPCenefas;
    @SerializedName("MatPOPColgantes")
    @Expose
    private Object matPOPColgantes;
    @SerializedName("MatPOPCorbata")
    @Expose
    private Object matPOPCorbata;
    @SerializedName("MatPOPDanglers")
    @Expose
    private Object matPOPDanglers;
    @SerializedName("MatPOPFaldon")
    @Expose
    private Object matPOPFaldon;
    @SerializedName("MatPOPFlash")
    @Expose
    private Object matPOPFlash;
    @SerializedName("MatPOPFolleto")
    @Expose
    private Object matPOPFolleto;
    @SerializedName("MatPOPOtros")
    @Expose
    private Object matPOPOtros;
    @SerializedName("MatPOPPreciador")
    @Expose
    private Object matPOPPreciador;
    @SerializedName("MatPOPStoppers")
    @Expose
    private Object matPOPStoppers;
    @SerializedName("MatPOPTapete")
    @Expose
    private Object matPOPTapete;
    @SerializedName("MatPOPTira")
    @Expose
    private Object matPOPTira;
    @SerializedName("Nielsen")
    @Expose
    private Object nielsen;
    @SerializedName("NuevoPunto")
    @Expose
    private Object nuevoPunto;
    @SerializedName("Numero")
    @Expose
    private Object numero;
    @SerializedName("Ojo")
    @Expose
    private Object ojo;
    @SerializedName("OjoC1")
    @Expose
    private Object ojoC1;
    @SerializedName("OjoC2")
    @Expose
    private Object ojoC2;
    @SerializedName("OjoC3")
    @Expose
    private Object ojoC3;
    @SerializedName("OjoC4")
    @Expose
    private Object ojoC4;
    @SerializedName("OjoFrentesEnFrio")
    @Expose
    private Object ojoFrentesEnFrio;
    @SerializedName("OtrosFrentes")
    @Expose
    private Object otrosFrentes;
    @SerializedName("Precio")
    @Expose
    private Object precio;
    @SerializedName("PrecioFrentesEnFrio")
    @Expose
    private Object precioFrentesEnFrio;
    @SerializedName("RangoGPS")
    @Expose
    private Object rangoGPS;
    @SerializedName("SKU")
    @Expose
    private Object sKU;
    @SerializedName("Statussync")
    @Expose
    private Integer statussync;
    @SerializedName("Sucursal")
    @Expose
    private String sucursal;
    @SerializedName("Suelo")
    @Expose
    private Object suelo;
    @SerializedName("SueloC1")
    @Expose
    private Object sueloC1;
    @SerializedName("SueloC2")
    @Expose
    private Object sueloC2;
    @SerializedName("SueloC3")
    @Expose
    private Object sueloC3;
    @SerializedName("SueloC4")
    @Expose
    private Object sueloC4;
    @SerializedName("SueloFrentesEnFrio")
    @Expose
    private Object sueloFrentesEnFrio;
    @SerializedName("TarimasBodega")
    @Expose
    private Object tarimasBodega;
    @SerializedName("Techo")
    @Expose
    private Object techo;
    @SerializedName("TechoC1")
    @Expose
    private Object techoC1;
    @SerializedName("TechoC2")
    @Expose
    private Object techoC2;
    @SerializedName("TechoC3")
    @Expose
    private Object techoC3;
    @SerializedName("TechoC4")
    @Expose
    private Object techoC4;
    @SerializedName("TechoFrentesEnFrio")
    @Expose
    private Object techoFrentesEnFrio;
    @SerializedName("Telefonos")
    @Expose
    private Object telefonos;
    @SerializedName("TirasFrentes")
    @Expose
    private Object tirasFrentes;
    @SerializedName("TramosAnaquel")
    @Expose
    private Object tramosAnaquel;
    @SerializedName("TramosFrentesEnFrio")
    @Expose
    private Object tramosFrentesEnFrio;
    @SerializedName("Ufechadescarga")
    @Expose
    private Object ufechadescarga;
    @SerializedName("agrupador")
    @Expose
    private String agrupador;
    @SerializedName("determinante")
    @Expose
    private String determinante;
    @SerializedName("nombreComercial")
    @Expose
    private String nombreComercial;

    public Integer getActivo() {
        return activo;
    }

    public void setActivo(Integer activo) {
        this.activo = activo;
    }

    public Integer getAltitud() {
        return altitud;
    }

    public void setAltitud(Integer altitud) {
        this.altitud = altitud;
    }

    public Object getAreaFlexFrentes() {
        return areaFlexFrentes;
    }

    public void setAreaFlexFrentes(Object areaFlexFrentes) {
        this.areaFlexFrentes = areaFlexFrentes;
    }

    public Object getArietesFrentes() {
        return arietesFrentes;
    }

    public void setArietesFrentes(Object arietesFrentes) {
        this.arietesFrentes = arietesFrentes;
    }

    public Object getBateria() {
        return bateria;
    }

    public void setBateria(Object bateria) {
        this.bateria = bateria;
    }

    public Integer getCP() {
        return cP;
    }

    public void setCP(Integer cP) {
        this.cP = cP;
    }

    public Object getCabeceraFrentes() {
        return cabeceraFrentes;
    }

    public void setCabeceraFrentes(Object cabeceraFrentes) {
        this.cabeceraFrentes = cabeceraFrentes;
    }

    public String getCadena() {
        return cadena;
    }

    public void setCadena(String cadena) {
        this.cadena = cadena;
    }

    public Object getCadenaFecha() {
        return cadenaFecha;
    }

    public void setCadenaFecha(Object cadenaFecha) {
        this.cadenaFecha = cadenaFecha;
    }

    public Object getCajasFrentes() {
        return cajasFrentes;
    }

    public void setCajasFrentes(Object cajasFrentes) {
        this.cajasFrentes = cajasFrentes;
    }

    public Object getCalle() {
        return calle;
    }

    public void setCalle(Object calle) {
        this.calle = calle;
    }

    public Object getCantAnaquel() {
        return cantAnaquel;
    }

    public void setCantAnaquel(Object cantAnaquel) {
        this.cantAnaquel = cantAnaquel;
    }

    public Object getCantBodega() {
        return cantBodega;
    }

    public void setCantBodega(Object cantBodega) {
        this.cantBodega = cantBodega;
    }

    public Object getCantFrentesEnFrio() {
        return cantFrentesEnFrio;
    }

    public void setCantFrentesEnFrio(Object cantFrentesEnFrio) {
        this.cantFrentesEnFrio = cantFrentesEnFrio;
    }

    public String getColonia() {
        return colonia;
    }

    public void setColonia(String colonia) {
        this.colonia = colonia;
    }

    public Object getComentarioAnaquel() {
        return comentarioAnaquel;
    }

    public void setComentarioAnaquel(Object comentarioAnaquel) {
        this.comentarioAnaquel = comentarioAnaquel;
    }

    public Object getComentarioBodega() {
        return comentarioBodega;
    }

    public void setComentarioBodega(Object comentarioBodega) {
        this.comentarioBodega = comentarioBodega;
    }

    public Object getComentarioExhAdic() {
        return comentarioExhAdic;
    }

    public void setComentarioExhAdic(Object comentarioExhAdic) {
        this.comentarioExhAdic = comentarioExhAdic;
    }

    public Object getComentarioFrentesEnFrio() {
        return comentarioFrentesEnFrio;
    }

    public void setComentarioFrentesEnFrio(Object comentarioFrentesEnFrio) {
        this.comentarioFrentesEnFrio = comentarioFrentesEnFrio;
    }

    public Integer getDeterminanteGSP() {
        return determinanteGSP;
    }

    public void setDeterminanteGSP(Integer determinanteGSP) {
        this.determinanteGSP = determinanteGSP;
    }

    public String getDeterminanteTienda() {
        return determinanteTienda;
    }

    public void setDeterminanteTienda(String determinanteTienda) {
        this.determinanteTienda = determinanteTienda;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Object getEstatus() {
        return estatus;
    }

    public void setEstatus(Object estatus) {
        this.estatus = estatus;
    }

    public Object getFacturacion() {
        return facturacion;
    }

    public void setFacturacion(Object facturacion) {
        this.facturacion = facturacion;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getFechaSync() {
        return fechaSync;
    }

    public void setFechaSync(String fechaSync) {
        this.fechaSync = fechaSync;
    }

    public Object getForwayFrentes() {
        return forwayFrentes;
    }

    public void setForwayFrentes(Object forwayFrentes) {
        this.forwayFrentes = forwayFrentes;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdCadena() {
        return idCadena;
    }

    public void setIdCadena(Integer idCadena) {
        this.idCadena = idCadena;
    }

    public Integer getIdCanal() {
        return idCanal;
    }

    public void setIdCanal(Integer idCanal) {
        this.idCanal = idCanal;
    }

    public Integer getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Integer idCategoria) {
        this.idCategoria = idCategoria;
    }

    public Object getIdCiudad() {
        return idCiudad;
    }

    public void setIdCiudad(Object idCiudad) {
        this.idCiudad = idCiudad;
    }

    public Object getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(Object idEstado) {
        this.idEstado = idEstado;
    }

    public Object getIdFormato() {
        return idFormato;
    }

    public void setIdFormato(Object idFormato) {
        this.idFormato = idFormato;
    }

    public Object getIdFoto() {
        return idFoto;
    }

    public void setIdFoto(Object idFoto) {
        this.idFoto = idFoto;
    }

    public Integer getIdGrupo() {
        return idGrupo;
    }

    public void setIdGrupo(Integer idGrupo) {
        this.idGrupo = idGrupo;
    }

    public Object getIdMunicipio() {
        return idMunicipio;
    }

    public void setIdMunicipio(Object idMunicipio) {
        this.idMunicipio = idMunicipio;
    }

    public Object getIdPais() {
        return idPais;
    }

    public void setIdPais(Object idPais) {
        this.idPais = idPais;
    }

    public Object getIdProyecto() {
        return idProyecto;
    }

    public void setIdProyecto(Object idProyecto) {
        this.idProyecto = idProyecto;
    }

    public Object getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(Object idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Integer getIdVisitaServer() {
        return idVisitaServer;
    }

    public void setIdVisitaServer(Integer idVisitaServer) {
        this.idVisitaServer = idVisitaServer;
    }

    public Object getIsAreaFlex() {
        return isAreaFlex;
    }

    public void setIsAreaFlex(Object isAreaFlex) {
        this.isAreaFlex = isAreaFlex;
    }

    public Object getIsAriete() {
        return isAriete;
    }

    public void setIsAriete(Object isAriete) {
        this.isAriete = isAriete;
    }

    public Object getIsBunkers() {
        return isBunkers;
    }

    public void setIsBunkers(Object isBunkers) {
        this.isBunkers = isBunkers;
    }

    public Object getIsC1() {
        return isC1;
    }

    public void setIsC1(Object isC1) {
        this.isC1 = isC1;
    }

    public Object getIsC2() {
        return isC2;
    }

    public void setIsC2(Object isC2) {
        this.isC2 = isC2;
    }

    public Object getIsC3() {
        return isC3;
    }

    public void setIsC3(Object isC3) {
        this.isC3 = isC3;
    }

    public Object getIsC4() {
        return isC4;
    }

    public void setIsC4(Object isC4) {
        this.isC4 = isC4;
    }

    public Object getIsCabecera() {
        return isCabecera;
    }

    public void setIsCabecera(Object isCabecera) {
        this.isCabecera = isCabecera;
    }

    public Object getIsCajas() {
        return isCajas;
    }

    public void setIsCajas(Object isCajas) {
        this.isCajas = isCajas;
    }

    public Object getIsExhibidores() {
        return isExhibidores;
    }

    public void setIsExhibidores(Object isExhibidores) {
        this.isExhibidores = isExhibidores;
    }

    public Object getIsForway() {
        return isForway;
    }

    public void setIsForway(Object isForway) {
        this.isForway = isForway;
    }

    public Object getIsIsla() {
        return isIsla;
    }

    public void setIsIsla(Object isIsla) {
        this.isIsla = isIsla;
    }

    public Object getIsMaterialPOP() {
        return isMaterialPOP;
    }

    public void setIsMaterialPOP(Object isMaterialPOP) {
        this.isMaterialPOP = isMaterialPOP;
    }

    public Object getIsOtro() {
        return isOtro;
    }

    public void setIsOtro(Object isOtro) {
        this.isOtro = isOtro;
    }

    public Object getIsTiras() {
        return isTiras;
    }

    public void setIsTiras(Object isTiras) {
        this.isTiras = isTiras;
    }

    public Object getIslasFrentes() {
        return islasFrentes;
    }

    public void setIslasFrentes(Object islasFrentes) {
        this.islasFrentes = islasFrentes;
    }

    public Double getLatitud() {
        return latitud;
    }

    public void setLatitud(Double latitud) {
        this.latitud = latitud;
    }

    public Double getLongitud() {
        return longitud;
    }

    public void setLongitud(Double longitud) {
        this.longitud = longitud;
    }

    public Object getManos() {
        return manos;
    }

    public void setManos(Object manos) {
        this.manos = manos;
    }

    public Object getManosC1() {
        return manosC1;
    }

    public void setManosC1(Object manosC1) {
        this.manosC1 = manosC1;
    }

    public Object getManosC2() {
        return manosC2;
    }

    public void setManosC2(Object manosC2) {
        this.manosC2 = manosC2;
    }

    public Object getManosC3() {
        return manosC3;
    }

    public void setManosC3(Object manosC3) {
        this.manosC3 = manosC3;
    }

    public Object getManosC4() {
        return manosC4;
    }

    public void setManosC4(Object manosC4) {
        this.manosC4 = manosC4;
    }

    public Object getManosFrentesEnFrio() {
        return manosFrentesEnFrio;
    }

    public void setManosFrentesEnFrio(Object manosFrentesEnFrio) {
        this.manosFrentesEnFrio = manosFrentesEnFrio;
    }

    public Object getMatPOPCartulina() {
        return matPOPCartulina;
    }

    public void setMatPOPCartulina(Object matPOPCartulina) {
        this.matPOPCartulina = matPOPCartulina;
    }

    public Object getMatPOPCenefas() {
        return matPOPCenefas;
    }

    public void setMatPOPCenefas(Object matPOPCenefas) {
        this.matPOPCenefas = matPOPCenefas;
    }

    public Object getMatPOPColgantes() {
        return matPOPColgantes;
    }

    public void setMatPOPColgantes(Object matPOPColgantes) {
        this.matPOPColgantes = matPOPColgantes;
    }

    public Object getMatPOPCorbata() {
        return matPOPCorbata;
    }

    public void setMatPOPCorbata(Object matPOPCorbata) {
        this.matPOPCorbata = matPOPCorbata;
    }

    public Object getMatPOPDanglers() {
        return matPOPDanglers;
    }

    public void setMatPOPDanglers(Object matPOPDanglers) {
        this.matPOPDanglers = matPOPDanglers;
    }

    public Object getMatPOPFaldon() {
        return matPOPFaldon;
    }

    public void setMatPOPFaldon(Object matPOPFaldon) {
        this.matPOPFaldon = matPOPFaldon;
    }

    public Object getMatPOPFlash() {
        return matPOPFlash;
    }

    public void setMatPOPFlash(Object matPOPFlash) {
        this.matPOPFlash = matPOPFlash;
    }

    public Object getMatPOPFolleto() {
        return matPOPFolleto;
    }

    public void setMatPOPFolleto(Object matPOPFolleto) {
        this.matPOPFolleto = matPOPFolleto;
    }

    public Object getMatPOPOtros() {
        return matPOPOtros;
    }

    public void setMatPOPOtros(Object matPOPOtros) {
        this.matPOPOtros = matPOPOtros;
    }

    public Object getMatPOPPreciador() {
        return matPOPPreciador;
    }

    public void setMatPOPPreciador(Object matPOPPreciador) {
        this.matPOPPreciador = matPOPPreciador;
    }

    public Object getMatPOPStoppers() {
        return matPOPStoppers;
    }

    public void setMatPOPStoppers(Object matPOPStoppers) {
        this.matPOPStoppers = matPOPStoppers;
    }

    public Object getMatPOPTapete() {
        return matPOPTapete;
    }

    public void setMatPOPTapete(Object matPOPTapete) {
        this.matPOPTapete = matPOPTapete;
    }

    public Object getMatPOPTira() {
        return matPOPTira;
    }

    public void setMatPOPTira(Object matPOPTira) {
        this.matPOPTira = matPOPTira;
    }

    public Object getNielsen() {
        return nielsen;
    }

    public void setNielsen(Object nielsen) {
        this.nielsen = nielsen;
    }

    public Object getNuevoPunto() {
        return nuevoPunto;
    }

    public void setNuevoPunto(Object nuevoPunto) {
        this.nuevoPunto = nuevoPunto;
    }

    public Object getNumero() {
        return numero;
    }

    public void setNumero(Object numero) {
        this.numero = numero;
    }

    public Object getOjo() {
        return ojo;
    }

    public void setOjo(Object ojo) {
        this.ojo = ojo;
    }

    public Object getOjoC1() {
        return ojoC1;
    }

    public void setOjoC1(Object ojoC1) {
        this.ojoC1 = ojoC1;
    }

    public Object getOjoC2() {
        return ojoC2;
    }

    public void setOjoC2(Object ojoC2) {
        this.ojoC2 = ojoC2;
    }

    public Object getOjoC3() {
        return ojoC3;
    }

    public void setOjoC3(Object ojoC3) {
        this.ojoC3 = ojoC3;
    }

    public Object getOjoC4() {
        return ojoC4;
    }

    public void setOjoC4(Object ojoC4) {
        this.ojoC4 = ojoC4;
    }

    public Object getOjoFrentesEnFrio() {
        return ojoFrentesEnFrio;
    }

    public void setOjoFrentesEnFrio(Object ojoFrentesEnFrio) {
        this.ojoFrentesEnFrio = ojoFrentesEnFrio;
    }

    public Object getOtrosFrentes() {
        return otrosFrentes;
    }

    public void setOtrosFrentes(Object otrosFrentes) {
        this.otrosFrentes = otrosFrentes;
    }

    public Object getPrecio() {
        return precio;
    }

    public void setPrecio(Object precio) {
        this.precio = precio;
    }

    public Object getPrecioFrentesEnFrio() {
        return precioFrentesEnFrio;
    }

    public void setPrecioFrentesEnFrio(Object precioFrentesEnFrio) {
        this.precioFrentesEnFrio = precioFrentesEnFrio;
    }

    public Object getRangoGPS() {
        return rangoGPS;
    }

    public void setRangoGPS(Object rangoGPS) {
        this.rangoGPS = rangoGPS;
    }

    public Object getSKU() {
        return sKU;
    }

    public void setSKU(Object sKU) {
        this.sKU = sKU;
    }

    public Integer getStatussync() {
        return statussync;
    }

    public void setStatussync(Integer statussync) {
        this.statussync = statussync;
    }

    public String getSucursal() {
        return sucursal;
    }

    public void setSucursal(String sucursal) {
        this.sucursal = sucursal;
    }

    public Object getSuelo() {
        return suelo;
    }

    public void setSuelo(Object suelo) {
        this.suelo = suelo;
    }

    public Object getSueloC1() {
        return sueloC1;
    }

    public void setSueloC1(Object sueloC1) {
        this.sueloC1 = sueloC1;
    }

    public Object getSueloC2() {
        return sueloC2;
    }

    public void setSueloC2(Object sueloC2) {
        this.sueloC2 = sueloC2;
    }

    public Object getSueloC3() {
        return sueloC3;
    }

    public void setSueloC3(Object sueloC3) {
        this.sueloC3 = sueloC3;
    }

    public Object getSueloC4() {
        return sueloC4;
    }

    public void setSueloC4(Object sueloC4) {
        this.sueloC4 = sueloC4;
    }

    public Object getSueloFrentesEnFrio() {
        return sueloFrentesEnFrio;
    }

    public void setSueloFrentesEnFrio(Object sueloFrentesEnFrio) {
        this.sueloFrentesEnFrio = sueloFrentesEnFrio;
    }

    public Object getTarimasBodega() {
        return tarimasBodega;
    }

    public void setTarimasBodega(Object tarimasBodega) {
        this.tarimasBodega = tarimasBodega;
    }

    public Object getTecho() {
        return techo;
    }

    public void setTecho(Object techo) {
        this.techo = techo;
    }

    public Object getTechoC1() {
        return techoC1;
    }

    public void setTechoC1(Object techoC1) {
        this.techoC1 = techoC1;
    }

    public Object getTechoC2() {
        return techoC2;
    }

    public void setTechoC2(Object techoC2) {
        this.techoC2 = techoC2;
    }

    public Object getTechoC3() {
        return techoC3;
    }

    public void setTechoC3(Object techoC3) {
        this.techoC3 = techoC3;
    }

    public Object getTechoC4() {
        return techoC4;
    }

    public void setTechoC4(Object techoC4) {
        this.techoC4 = techoC4;
    }

    public Object getTechoFrentesEnFrio() {
        return techoFrentesEnFrio;
    }

    public void setTechoFrentesEnFrio(Object techoFrentesEnFrio) {
        this.techoFrentesEnFrio = techoFrentesEnFrio;
    }

    public Object getTelefonos() {
        return telefonos;
    }

    public void setTelefonos(Object telefonos) {
        this.telefonos = telefonos;
    }

    public Object getTirasFrentes() {
        return tirasFrentes;
    }

    public void setTirasFrentes(Object tirasFrentes) {
        this.tirasFrentes = tirasFrentes;
    }

    public Object getTramosAnaquel() {
        return tramosAnaquel;
    }

    public void setTramosAnaquel(Object tramosAnaquel) {
        this.tramosAnaquel = tramosAnaquel;
    }

    public Object getTramosFrentesEnFrio() {
        return tramosFrentesEnFrio;
    }

    public void setTramosFrentesEnFrio(Object tramosFrentesEnFrio) {
        this.tramosFrentesEnFrio = tramosFrentesEnFrio;
    }

    public Object getUfechadescarga() {
        return ufechadescarga;
    }

    public void setUfechadescarga(Object ufechadescarga) {
        this.ufechadescarga = ufechadescarga;
    }

    public String getAgrupador() {
        return agrupador;
    }

    public void setAgrupador(String agrupador) {
        this.agrupador = agrupador;
    }

    public String getDeterminante() {
        return determinante;
    }

    public void setDeterminante(String determinante) {
        this.determinante = determinante;
    }

    public String getNombreComercial() {
        return nombreComercial;
    }

    public void setNombreComercial(String nombreComercial) {
        this.nombreComercial = nombreComercial;
    }

}