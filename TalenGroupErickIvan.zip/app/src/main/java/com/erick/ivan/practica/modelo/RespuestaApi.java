package com.erick.ivan.practica.modelo;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RespuestaApi {

    @SerializedName("getConjuntotiendasUsuarioResult")
    @Expose
    private List<GetConjuntotiendasUsuarioResult> getConjuntotiendasUsuarioResult = null;

    public List<GetConjuntotiendasUsuarioResult> getGetConjuntotiendasUsuarioResult() {
        return getConjuntotiendasUsuarioResult;
    }

    public void setGetConjuntotiendasUsuarioResult(List<GetConjuntotiendasUsuarioResult> getConjuntotiendasUsuarioResult) {
        this.getConjuntotiendasUsuarioResult = getConjuntotiendasUsuarioResult;
    }

}