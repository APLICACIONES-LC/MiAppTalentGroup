package com.erick.ivan.practica.modelo.remote;


import com.erick.ivan.practica.controlador.WebServiceClient;

public class ApiUtils {
    private ApiUtils() {}


    private final static String URL_GENERAL="http://www.webteam.mx/Demo/Tracker.Procesos.svc/";

    public static WebServiceClient getAPIService() {

        return RetrofitClient.getClient(URL_GENERAL).create(WebServiceClient.class);
    }
}
