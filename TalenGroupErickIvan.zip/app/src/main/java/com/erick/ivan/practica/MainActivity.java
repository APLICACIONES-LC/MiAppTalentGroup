package com.erick.ivan.practica;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.erick.ivan.practica.bd.BdDatos;
import com.erick.ivan.practica.controlador.WebServiceClient;
import com.erick.ivan.practica.modelo.GetConjuntotiendasUsuarioResult;
import com.erick.ivan.practica.modelo.RespuestaApi;
import com.erick.ivan.practica.modelo.remote.ApiUtils;

import org.json.JSONException;
import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private WebServiceClient mAPIService;
    public BdDatos db = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new BdDatos(this);

        mAPIService = ApiUtils.getAPIService();
        sendPost();
    }


    public void sendPost() {
        String retorno=db.eliminar();
        System.out.println(retorno);
        String miJson="{\n" +
                "\"Usuario\":{\n" +
                "\t\"Id\":\"11208\"\n" +
                "\t},\n" +
                "\"Proyecto\":{\n" +
                "\"Id\":\"137\", \"Ufechadescarga\" : 0\n" +
                "\t}\n" +
                "}";

        JSONObject paramObject=null;
        try {

          paramObject=new JSONObject(miJson);


        } catch (JSONException e) {
            e.printStackTrace();
        }

        mAPIService.misDatos(paramObject.toString()).enqueue(new Callback<RespuestaApi>() {
            @Override
            public void onResponse(Call<RespuestaApi> call, Response<RespuestaApi> response) {

                if(response.isSuccessful()) {

                    for (GetConjuntotiendasUsuarioResult valores : response.body().getGetConjuntotiendasUsuarioResult()){
                        db.lecturaDeFicheroBD(valores);
                    }
                    System.out.println(db.getAll("LA VILLA"));

                    Log.i("Tag1", "exitoso." + response.body().getGetConjuntotiendasUsuarioResult().get(1).getId());
                }
            }

            @Override
            public void onFailure(Call<RespuestaApi> call, Throwable t) {
                Log.e("Tag1", "no sirve."+t);
            }
        });
    }

}
