package com.erick.ivan.practica.bd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.erick.ivan.practica.modelo.GetConjuntotiendasUsuarioResult;

import java.util.ArrayList;
import java.util.Scanner;

public class BdDatos extends SQLiteOpenHelper {

    private static BdDatos instance = null;

    private Context context;
    private static final String DATABASE_NAME = "misDatos";
    private static final int DATABASE_VERSION = 4;



    public static BdDatos getInstance(Context context) {
        if(instance == null) {
            instance = new BdDatos(context);
        }
        return instance;
    }

    public BdDatos(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }




    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE datosLocalizacion (" +
                "Activo Varchar(100),"+
                "Altitud Varchar(100),"+
                "CP Varchar(100),"+
                "Cadena Varchar(100),"+
                "Colonia Varchar(100),"+
                "DeterminanteGSP Varchar(100),"+
                "DeterminanteTienda Varchar(100),"+
                "Direccion Varchar(100),"+
                "Fecha Varchar(100),"+
                "FechaSync Varchar(100),"+
                "Id Varchar(100),"+
                "IdCadena Varchar(100),"+
                "IdCanal Varchar(100),"+
                "IdCategoria Varchar(100),"+
                "IdGrupo Varchar(100),"+
                "IdVisita_Server Varchar(100),"+
                "Latitud Varchar(100),"+
                "Longitud Varchar(100),"+
                "Statussync Varchar(100),"+
                "Sucursal Varchar(100),"+
                "agrupador Varchar(100),"+
                "determinante Varchar(100),"+
                "nombreComercial Varchar(100))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS datosLocalizacion");
        onCreate(db);
    }

    public void lecturaDeFicheroBD(GetConjuntotiendasUsuarioResult valores) {
        String[] p;
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues values = new ContentValues();

            p = "".split(";");
            values.put("Activo", valores.getActivo());
            values.put("Altitud", valores.getAltitud());
            values.put("CP", valores.getCP());
            values.put("Cadena", valores.getCadena());
            values.put("Colonia", valores.getColonia());
            values.put("DeterminanteGSP", valores.getDeterminanteGSP());
            values.put("DeterminanteTienda", valores.getDeterminanteTienda());
            values.put("Direccion", valores.getDireccion());
            values.put("Fecha", valores.getFecha());
            values.put("FechaSync", valores.getFechaSync());
            values.put("Id", valores.getId());
            values.put("IdCadena", valores.getIdCadena());
            values.put("IdCanal", valores.getIdCanal());
            values.put("IdCategoria", valores.getIdCategoria());
            values.put("IdGrupo", valores.getIdGrupo());
            values.put("IdVisita_Server", valores.getIdVisitaServer());
            values.put("Latitud", valores.getCadena());
            values.put("Longitud", valores.getCadena());
            values.put("Statussync", valores.getCadena());
            values.put("Sucursal", valores.getCadena());
            values.put("agrupador", valores.getAgrupador());
            values.put("determinante", valores.getDeterminante());
            values.put("nombreComercial", valores.getNombreComercial());



            db.insert("datosLocalizacion",null,values);

    }

    /**
     * Es un metodo temporal
     * @return
     */
    public String eliminar() {
        String mensaje = "";
        SQLiteDatabase database = this.getWritableDatabase();
        int cantidad = database.delete("datosLocalizacion", null, null);
        if (cantidad != 0) {

            mensaje = "Eliminado Correctamente";

        } else {

            mensaje = "No existe";
        }
        database.close();
        return mensaje;
    }

    public String getAll(String sucursal) {
String retorna="";
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM datosLocalizacion WHERE sucursal = '" + sucursal + "'",null);
        if(c.moveToFirst()) {
            do {
retorna=c.getString(3);
            } while (c.moveToNext());
        }
        db.close();

        return retorna;
    }
}